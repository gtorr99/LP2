﻿namespace PtesteMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSair = new System.Windows.Forms.Button();
            this.btnRemoveOcorrenciasReplace = new System.Windows.Forms.Button();
            this.btnReverteTexto1 = new System.Windows.Forms.Button();
            this.btnRemoveOcorrenciasIndexOf = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnSair
            // 
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(224, 138);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(173, 45);
            this.btnSair.TabIndex = 6;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnRemoveOcorrenciasReplace
            // 
            this.btnRemoveOcorrenciasReplace.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveOcorrenciasReplace.Location = new System.Drawing.Point(224, 87);
            this.btnRemoveOcorrenciasReplace.Name = "btnRemoveOcorrenciasReplace";
            this.btnRemoveOcorrenciasReplace.Size = new System.Drawing.Size(173, 45);
            this.btnRemoveOcorrenciasReplace.TabIndex = 4;
            this.btnRemoveOcorrenciasReplace.Text = "Remover Ocorrencias Texto 1 (Replace)";
            this.btnRemoveOcorrenciasReplace.UseVisualStyleBackColor = true;
            this.btnRemoveOcorrenciasReplace.Click += new System.EventHandler(this.btnRemoveOcorrenciasReplace_Click);
            // 
            // btnReverteTexto1
            // 
            this.btnReverteTexto1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReverteTexto1.Location = new System.Drawing.Point(45, 138);
            this.btnReverteTexto1.Name = "btnReverteTexto1";
            this.btnReverteTexto1.Size = new System.Drawing.Size(173, 45);
            this.btnReverteTexto1.TabIndex = 5;
            this.btnReverteTexto1.Text = "Reverter Texto 1";
            this.btnReverteTexto1.UseVisualStyleBackColor = true;
            this.btnReverteTexto1.Click += new System.EventHandler(this.btnReverteTexto1_Click);
            // 
            // btnRemoveOcorrenciasIndexOf
            // 
            this.btnRemoveOcorrenciasIndexOf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveOcorrenciasIndexOf.Location = new System.Drawing.Point(45, 87);
            this.btnRemoveOcorrenciasIndexOf.Name = "btnRemoveOcorrenciasIndexOf";
            this.btnRemoveOcorrenciasIndexOf.Size = new System.Drawing.Size(173, 45);
            this.btnRemoveOcorrenciasIndexOf.TabIndex = 3;
            this.btnRemoveOcorrenciasIndexOf.Text = "Remover Ocorrencias Texto 1 (Index)";
            this.btnRemoveOcorrenciasIndexOf.UseVisualStyleBackColor = true;
            this.btnRemoveOcorrenciasIndexOf.Click += new System.EventHandler(this.btnRemoveOcorrenciasIndexOf_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(42, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Palavra 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "Palavra 1";
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPalavra2.Location = new System.Drawing.Point(122, 52);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(275, 22);
            this.txtPalavra2.TabIndex = 2;
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPalavra1.Location = new System.Drawing.Point(122, 26);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(275, 22);
            this.txtPalavra1.TabIndex = 0;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnRemoveOcorrenciasReplace);
            this.Controls.Add(this.btnReverteTexto1);
            this.Controls.Add(this.btnRemoveOcorrenciasIndexOf);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnRemoveOcorrenciasReplace;
        private System.Windows.Forms.Button btnReverteTexto1;
        private System.Windows.Forms.Button btnRemoveOcorrenciasIndexOf;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.TextBox txtPalavra1;
    }
}