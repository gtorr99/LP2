﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        private int _num1;
        private int _num2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (Int32.TryParse(txtNumero1.Text, out _num1) && _num1 > -1
                && Int32.TryParse(txtNumero2.Text, out _num2) && _num2 > -1)
            {
                Random random = new Random();
                int numSorteado = random.Next(_num1, _num2);
                MessageBox.Show($"Número sorteado: {numSorteado}");
            }
            else
            {
                MessageBox.Show("Digite somente números naturais!");
                txtNumero1.Focus();
            }
        }
    }
}
