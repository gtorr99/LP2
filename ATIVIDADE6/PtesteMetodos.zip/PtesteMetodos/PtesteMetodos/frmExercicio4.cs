﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnTotalNum_Click(object sender, EventArgs e)
        {
            int totalNumericos = 0; 
            for (int i = 0; i < richTxt.TextLength; i++)
            {
                if (Char.IsNumber(richTxt.Text, i))
                {
                    totalNumericos++;
                }
            }

            MessageBox.Show($"Total caracteres numéricos: {totalNumericos}");
        }

        private void btnPrimeiroCharBranco_Click(object sender, EventArgs e)
        {
            int i = 0;
            while (i < richTxt.Text.Length && !Char.IsWhiteSpace(richTxt.Text, i)) 
            {
                i++;
            }

            if (i == richTxt.Text.Length)
            {
                MessageBox.Show("Não há espaços em branco!");
            }
            else
            {
                MessageBox.Show($"Posição 1º caracter branco: {i}");
            }
        }

        private void btnTotalAlpha_Click(object sender, EventArgs e)
        {
            int totalAlpha = 0;
            foreach(char c in richTxt.Text)
            {
                if (Char.IsLetter(c))
                {
                    totalAlpha++;
                }
            }

            MessageBox.Show($"Total caracteres alfabéticos: {totalAlpha}");
        }
    }
}
