﻿namespace PtesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTxt = new System.Windows.Forms.RichTextBox();
            this.btnTotalNum = new System.Windows.Forms.Button();
            this.btnPrimeiroCharBranco = new System.Windows.Forms.Button();
            this.btnTotalAlpha = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTxt
            // 
            this.richTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTxt.Location = new System.Drawing.Point(52, 37);
            this.richTxt.Name = "richTxt";
            this.richTxt.Size = new System.Drawing.Size(603, 136);
            this.richTxt.TabIndex = 0;
            this.richTxt.Text = "";
            // 
            // btnTotalNum
            // 
            this.btnTotalNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotalNum.Location = new System.Drawing.Point(52, 179);
            this.btnTotalNum.Name = "btnTotalNum";
            this.btnTotalNum.Size = new System.Drawing.Size(197, 48);
            this.btnTotalNum.TabIndex = 1;
            this.btnTotalNum.Text = "Total Numéricos";
            this.btnTotalNum.UseVisualStyleBackColor = true;
            this.btnTotalNum.Click += new System.EventHandler(this.btnTotalNum_Click);
            // 
            // btnPrimeiroCharBranco
            // 
            this.btnPrimeiroCharBranco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrimeiroCharBranco.Location = new System.Drawing.Point(255, 179);
            this.btnPrimeiroCharBranco.Name = "btnPrimeiroCharBranco";
            this.btnPrimeiroCharBranco.Size = new System.Drawing.Size(197, 48);
            this.btnPrimeiroCharBranco.TabIndex = 2;
            this.btnPrimeiroCharBranco.Text = "Primeiro Espaço Branco";
            this.btnPrimeiroCharBranco.UseVisualStyleBackColor = true;
            this.btnPrimeiroCharBranco.Click += new System.EventHandler(this.btnPrimeiroCharBranco_Click);
            // 
            // btnTotalAlpha
            // 
            this.btnTotalAlpha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotalAlpha.Location = new System.Drawing.Point(458, 179);
            this.btnTotalAlpha.Name = "btnTotalAlpha";
            this.btnTotalAlpha.Size = new System.Drawing.Size(197, 48);
            this.btnTotalAlpha.TabIndex = 3;
            this.btnTotalAlpha.Text = "Total Letras";
            this.btnTotalAlpha.UseVisualStyleBackColor = true;
            this.btnTotalAlpha.Click += new System.EventHandler(this.btnTotalAlpha_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnTotalAlpha);
            this.Controls.Add(this.btnPrimeiroCharBranco);
            this.Controls.Add(this.btnTotalNum);
            this.Controls.Add(this.richTxt);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTxt;
        private System.Windows.Forms.Button btnTotalNum;
        private System.Windows.Forms.Button btnPrimeiroCharBranco;
        private System.Windows.Forms.Button btnTotalAlpha;
    }
}