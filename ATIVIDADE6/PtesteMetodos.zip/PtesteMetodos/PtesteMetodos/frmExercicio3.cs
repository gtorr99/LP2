﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRemoveOcorrenciasIndexOf_Click(object sender, EventArgs e)
        {
            txtPalavra1.Text = txtPalavra1.Text.ToUpper();
            txtPalavra2.Text = txtPalavra2.Text.ToUpper();

            int indexTxt1 = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
            int lengthTxt1 = txtPalavra1.Text.Length;
            while (indexTxt1 != -1)
            {
                txtPalavra2.Text = txtPalavra2.Text.Substring(0, indexTxt1) +
                txtPalavra2.Text.Substring(indexTxt1 + lengthTxt1, txtPalavra2.Text.Length - indexTxt1 - lengthTxt1);

                indexTxt1 = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
            }
        }

        private void btnRemoveOcorrenciasReplace_Click(object sender, EventArgs e)
        {
            txtPalavra1.Text = txtPalavra1.Text.ToUpper();
            txtPalavra2.Text = txtPalavra2.Text.ToUpper();
            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
        }

        private void btnReverteTexto1_Click(object sender, EventArgs e)
        {
            txtPalavra1.Text = new string (txtPalavra1.Text.Reverse().ToArray());
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
