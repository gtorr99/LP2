﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio2 : Form
    {
        private int _numN;
        private double _numH;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcularH_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumN.Text, out _numN) || _numN < 1)
            {
                MessageBox.Show("Número Inválido!");
                txtNumN.Focus();
                return;
            }

            CalcularH();
            MessageBox.Show($"Número H = {_numH}");
        }

        private void CalcularH()
        {
            _numH = 1;
            for(int i = 2; i <= _numN; i++)
            {
                _numH += (double) 1 / i;
            }
        }
    }
}
