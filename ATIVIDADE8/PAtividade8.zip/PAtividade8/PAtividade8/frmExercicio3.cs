﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificarPalindromo_Click(object sender, EventArgs e)
        {
            string palavra = txtPalavra.Text.Replace(" ", "").ToUpper();
            string palindromo = new string(palavra.Reverse().ToArray());

            if (palavra == palindromo)
            {
                MessageBox.Show($"Palíndromo! - {palindromo}");
            }
            else
            {
                MessageBox.Show("Não é palíndromo");
            }

            txtPalavra.Focus();
        }
    }
}
