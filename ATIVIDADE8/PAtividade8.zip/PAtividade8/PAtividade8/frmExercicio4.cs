﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio4 : Form
    {
        private double _salario;
        private double _salarioBruto;
        private double _gratificacao;
        private int _producao;
        private int _B;
        private int _C;
        private int _D;

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcularBruto_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtProducao.Text, out _producao) || _producao < 0)
            {
                MessageBox.Show("Produção deve ser um número natural!");
                txtProducao.Focus();
                return;
            }

            if(!Double.TryParse(mskTxtSalario.Text, out _salario) || _salario < 1)
            {
                MessageBox.Show("Salário deve ser um valor númerico maior que zero!");
                mskTxtSalario.Focus();
                return;
            }

            if (!Double.TryParse(mskTxtGratificacao.Text, out _gratificacao) || _gratificacao < 0)
            {
                MessageBox.Show("Gratificação deve ser um valor númerico positivo!");
                mskTxtGratificacao.Focus();
                return;
            }

            _B = _producao >= 100 ? 1 : 0;
            _C = _producao >= 120 ? 1 : 0;
            _D = _producao >= 150 ? 1 : 0;

            CalcularSalarioBruto();
        }

        private void CalcularSalarioBruto()
        {
            _salarioBruto = _salario + _salario * (0.05 * _B + 0.1 * _C + 0.1 * _D) + _gratificacao;

            if (_salarioBruto > 7000 && (_D == 0 || _gratificacao == 0))
            {
                _salarioBruto = 0;
            }

            txtSalarioBruto.Text = _salarioBruto.ToString();
        }
    }
}