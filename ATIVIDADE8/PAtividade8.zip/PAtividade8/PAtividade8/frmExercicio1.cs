﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int qtdeEspacosBranco = 0;
            foreach (char c in richTxt.Text)
            {
                if (Char.IsWhiteSpace(c))
                {
                    qtdeEspacosBranco++;
                }
            }
            MessageBox.Show($"Total espaços em branco: {qtdeEspacosBranco}");
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            string str = richTxt.Text.ToUpper();
            int qtdeLetrasR = 0;
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == 'R')
                {
                    qtdeLetrasR++;
                }
            }
            MessageBox.Show($"Total de letras 'R': {qtdeLetrasR}");
        }

        private void btnLetraRepetida_Click(object sender, EventArgs e)
        {
            string str = richTxt.Text.ToUpper();
            int qtdeParesRepetidos = 0;
            int i = 0;

            while (i < str.Length - 1)
            {
                if (Char.IsLetter(str[i]) && str[i] == str[i + 1])
                {
                    qtdeParesRepetidos++;
                }

                i++;
            }

            MessageBox.Show($"Total pares de letras repetidas: {qtdeParesRepetidos}");

        }
    }
}
