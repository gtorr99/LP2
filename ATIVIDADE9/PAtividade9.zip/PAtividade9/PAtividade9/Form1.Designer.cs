﻿namespace PAtividade9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStripItemExercicio1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripItemExercicio2 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripItemExercicio3 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripItemExercicio4 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripItemExercicio5 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripItemExercicio6 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripItemSair = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuStripItemExercicio1,
            this.menuStripItemExercicio2,
            this.menuStripItemExercicio3,
            this.menuStripItemExercicio4,
            this.menuStripItemExercicio5,
            this.menuStripItemExercicio6,
            this.menuStripItemSair});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuStripItemExercicio1
            // 
            this.menuStripItemExercicio1.Name = "menuStripItemExercicio1";
            this.menuStripItemExercicio1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D1)));
            this.menuStripItemExercicio1.Size = new System.Drawing.Size(75, 20);
            this.menuStripItemExercicio1.Text = "Exercício &1";
            this.menuStripItemExercicio1.Click += new System.EventHandler(this.menuStripItemExercicio1_Click);
            // 
            // menuStripItemExercicio2
            // 
            this.menuStripItemExercicio2.Name = "menuStripItemExercicio2";
            this.menuStripItemExercicio2.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D2)));
            this.menuStripItemExercicio2.Size = new System.Drawing.Size(75, 20);
            this.menuStripItemExercicio2.Text = "Exercício &2";
            this.menuStripItemExercicio2.Click += new System.EventHandler(this.menuStripItemExercicio2_Click);
            // 
            // menuStripItemExercicio3
            // 
            this.menuStripItemExercicio3.Name = "menuStripItemExercicio3";
            this.menuStripItemExercicio3.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D3)));
            this.menuStripItemExercicio3.Size = new System.Drawing.Size(75, 20);
            this.menuStripItemExercicio3.Text = "Exercício &3";
            this.menuStripItemExercicio3.Click += new System.EventHandler(this.menuStripItemExercicio3_Click);
            // 
            // menuStripItemExercicio4
            // 
            this.menuStripItemExercicio4.Name = "menuStripItemExercicio4";
            this.menuStripItemExercicio4.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D4)));
            this.menuStripItemExercicio4.Size = new System.Drawing.Size(75, 20);
            this.menuStripItemExercicio4.Text = "Exercício &4";
            this.menuStripItemExercicio4.Click += new System.EventHandler(this.menuStripItemExercicio4_Click);
            // 
            // menuStripItemExercicio5
            // 
            this.menuStripItemExercicio5.Name = "menuStripItemExercicio5";
            this.menuStripItemExercicio5.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D5)));
            this.menuStripItemExercicio5.Size = new System.Drawing.Size(75, 20);
            this.menuStripItemExercicio5.Text = "Exercício &5";
            this.menuStripItemExercicio5.Click += new System.EventHandler(this.menuStripItemExercicio5_Click);
            // 
            // menuStripItemExercicio6
            // 
            this.menuStripItemExercicio6.Name = "menuStripItemExercicio6";
            this.menuStripItemExercicio6.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D6)));
            this.menuStripItemExercicio6.Size = new System.Drawing.Size(75, 20);
            this.menuStripItemExercicio6.Text = "Exercício &6";
            this.menuStripItemExercicio6.Click += new System.EventHandler(this.menuStripItemExercicio6_Click);
            // 
            // menuStripItemSair
            // 
            this.menuStripItemSair.Name = "menuStripItemSair";
            this.menuStripItemSair.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.menuStripItemSair.Size = new System.Drawing.Size(38, 20);
            this.menuStripItemSair.Text = "&Sair";
            this.menuStripItemSair.Click += new System.EventHandler(this.menuStripItemSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuStripItemExercicio1;
        private System.Windows.Forms.ToolStripMenuItem menuStripItemExercicio2;
        private System.Windows.Forms.ToolStripMenuItem menuStripItemExercicio3;
        private System.Windows.Forms.ToolStripMenuItem menuStripItemExercicio4;
        private System.Windows.Forms.ToolStripMenuItem menuStripItemExercicio5;
        private System.Windows.Forms.ToolStripMenuItem menuStripItemExercicio6;
        private System.Windows.Forms.ToolStripMenuItem menuStripItemSair;
    }
}

