﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio4 : Form
    {
        private ArrayList _alunos = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCarregarListaAlunos_Click(object sender, EventArgs e)
        {
            _alunos.Remove("Otávio");

            string nomes = "";

            foreach(string aluno in _alunos)
            {
                nomes += aluno + " ";
            }

            MessageBox.Show(nomes.Trim().Replace(" ", ", "));
        }
    }
}
