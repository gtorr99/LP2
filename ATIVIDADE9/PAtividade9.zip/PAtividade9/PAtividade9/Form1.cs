﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void VerificarFormAberto(string formName)
        {
            Form fc = Application.OpenForms[formName];

            if (fc != null)
            {
                fc.Close();
            }
        }

        private void menuStripItemExercicio1_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmExercicio1");

            frmExercicio1 frm = new frmExercicio1
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized,
            };

            frm.Show();
        }

        private void menuStripItemSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void menuStripItemExercicio2_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmExercicio2");

            frmExercicio2 frm = new frmExercicio2
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized,
            };

            frm.Show();
        }

        private void menuStripItemExercicio3_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmExercicio3");

            frmExercicio3 frm = new frmExercicio3
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized,
            };

            frm.Show();
        }

        private void menuStripItemExercicio4_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmExercicio4");

            frmExercicio4 frm = new frmExercicio4
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized,
            };

            frm.Show();
        }

        private void menuStripItemExercicio5_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmExercicio5");

            frmExercicio5 frm = new frmExercicio5
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized,
            };

            frm.Show();
        }

        private void menuStripItemExercicio6_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmExercicio6");

            frmExercicio6 frm = new frmExercicio6
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized,
            };

            frm.Show();
        }
    }
}
