﻿namespace PAtividade9
{
    partial class frmExercicio6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstbxNomes = new System.Windows.Forms.ListBox();
            this.btnCalcularTamanhoNomes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstbxNomes
            // 
            this.lstbxNomes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstbxNomes.FormattingEnabled = true;
            this.lstbxNomes.ItemHeight = 16;
            this.lstbxNomes.Items.AddRange(new object[] {
            " "});
            this.lstbxNomes.Location = new System.Drawing.Point(12, 12);
            this.lstbxNomes.Name = "lstbxNomes";
            this.lstbxNomes.Size = new System.Drawing.Size(540, 388);
            this.lstbxNomes.TabIndex = 0;
            // 
            // btnCalcularTamanhoNomes
            // 
            this.btnCalcularTamanhoNomes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcularTamanhoNomes.Location = new System.Drawing.Point(558, 353);
            this.btnCalcularTamanhoNomes.Name = "btnCalcularTamanhoNomes";
            this.btnCalcularTamanhoNomes.Size = new System.Drawing.Size(230, 47);
            this.btnCalcularTamanhoNomes.TabIndex = 1;
            this.btnCalcularTamanhoNomes.Text = "Calcular Tamanho Nomes";
            this.btnCalcularTamanhoNomes.UseVisualStyleBackColor = true;
            this.btnCalcularTamanhoNomes.Click += new System.EventHandler(this.btnCalcularTamanhoNomes_Click);
            // 
            // frmExercicio6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcularTamanhoNomes);
            this.Controls.Add(this.lstbxNomes);
            this.Name = "frmExercicio6";
            this.Text = "frmExercicio6";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstbxNomes;
        private System.Windows.Forms.Button btnCalcularTamanhoNomes;
    }
}