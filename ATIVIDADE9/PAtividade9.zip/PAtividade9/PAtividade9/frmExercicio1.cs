﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio1 : Form
    {
        private int[] _vetor;
        private string _aux;

        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void PopulaVetor()
        {
            _vetor = new int[20];

            for (int i = 0; i < 20; i++)
            {
                _aux = Interaction.InputBox("Digite um número inteiro", "Exercício 1");

                if (!int.TryParse(_aux, out _vetor[i]))
                {
                    MessageBox.Show("Valor Inválido!");
                    i--;
                }

            }
        }

        private void InverteVetor()
        {
            Array.Reverse(_vetor);
        }

        private void ImprimeVetor()
        {
            _aux = "";

            foreach (int num in _vetor)
            {
                _aux += "\n" + num;
            }

            MessageBox.Show("Lista invertida: " + _aux);
        }

        private void btnCarregarLista_Click(object sender, EventArgs e)
        {
            PopulaVetor();
            InverteVetor();
            ImprimeVetor();
        }
    }
}
