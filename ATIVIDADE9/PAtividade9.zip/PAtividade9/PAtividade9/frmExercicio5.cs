﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio5 : Form
    {
        private int _turma = 1;
        private char _separador = ';';
        private decimal[,] _mediasPorAluno;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnInserirNotas_Click(object sender, EventArgs e)
        {
            _mediasPorAluno = new decimal[_turma, 3];
            decimal media = 0;
            string notas;
            StringBuilder sb = new StringBuilder();

            for (int alunoPos = 0; alunoPos < _turma; alunoPos++)
            {
                notas = Interaction.InputBox($"Notas aluno {alunoPos + 1} (separadas por '{_separador}')", "Notas");

                if (notas == "")
                {
                    return;
                }

                int notaPos = 0;
                foreach (string nota in notas.Split(_separador))
                {
                    if (nota == "" | 
                        !Decimal.TryParse(nota, out _mediasPorAluno[alunoPos, notaPos])
                        | (_mediasPorAluno[alunoPos, notaPos] < 0 | _mediasPorAluno[alunoPos, notaPos] > 10))
                    {
                        MessageBox.Show($"Nota {notaPos + 1} deve ser um número entre 0 e 10");
                        alunoPos--;
                        break;
                    }

                    media += _mediasPorAluno[alunoPos, notaPos];
                    notaPos++;
                }

                if (notaPos == 3)
                {
                    media = (_mediasPorAluno[alunoPos, 0] + _mediasPorAluno[alunoPos, 1] + _mediasPorAluno[alunoPos, 2]) / 3;
                    sb.AppendLine($"Aluno {alunoPos + 1}: média: {Decimal.Round(media, 1)}");
                }
            }

            MessageBox.Show(sb.ToString());
        }
    }
}
