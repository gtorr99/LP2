﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio2 : Form
    {
        private int[] _vQuantidade;
        private double[] _vPreco;
        private const int _qtdeTiposMercadorias = 3;
        private const char _separador = '-';

        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnControleVendas_Click(object sender, EventArgs e)
        {
            RecebeVendas();
            CalculaFaturamentoMensal();
        }

        private void RecebeVendas()
        {
            _vQuantidade = new int[_qtdeTiposMercadorias];
            _vPreco = new double[_qtdeTiposMercadorias];

            string aux;

            for (int i = 0; i < _qtdeTiposMercadorias; i++)
            {

                aux = Interaction.InputBox($"Item {i + 1}\n" +
                    "Informe a quantidade vendida separada do preço unitário conforme modelo abaixo.\n" +
                    $"Quantidade{_separador}Preço Un.");

                if(aux == "")
                {
                    return;
                }

                if (aux.IndexOf(_separador) == -1)
                {
                    MessageBox.Show("Formatação Incorreta. Use o modelo");
                    i--;
                    continue;
                }

                if(!int.TryParse(aux.Substring(0, aux.IndexOf(_separador)).Trim(), out _vQuantidade[i]))
                {
                    MessageBox.Show("Quantidade Inválida!");
                    i--;
                    continue;
                }

                int indexSeparador = aux.IndexOf(_separador);

                if (!double.TryParse(aux.Substring(indexSeparador + 1, aux.Length - aux.Substring(0, indexSeparador + 1).Length).Trim(), out _vPreco[i]))
                {
                    MessageBox.Show("Preço Inválido!");
                    i--;
                    continue;
                }
            }

        }

        private void CalculaFaturamentoMensal()
        {
            double faturamento = 0;
            for(int i = 0; i < _qtdeTiposMercadorias; i++)
            {
                faturamento += _vQuantidade[i] * _vPreco[i];
            }
            MessageBox.Show($"Faturamento mensal: {faturamento}");
        }
    }
}
