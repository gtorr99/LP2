﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade9
{
    public partial class frmExercicio3 : Form
    {
        private string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };

        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnCalcularTotal_Click(object sender, EventArgs e)
        {
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;

            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }

            txtTotal.Text = Total.ToString();
            MessageBox.Show(txtTotal.Text, "Total");
        }
    }
}
