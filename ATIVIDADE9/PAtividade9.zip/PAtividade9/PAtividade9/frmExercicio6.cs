﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio6 : Form
    {
        private int _N = 9;
        private List<string> nomes = new List<string>();
        private List<int> tamanhos = new List<int>();
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnCalcularTamanhoNomes_Click(object sender, EventArgs e)
        {
            lstbxNomes.Items.Clear();
            for (int i = 0; i < _N; i++)
            {
                nomes.Add(Interaction.InputBox("Insira um nome:", "Nome"));
                if (nomes[i] == "") return;
                tamanhos.Add(nomes[i].Replace(" ", "").Length);
                lstbxNomes.Items.Add($"O nome: {nomes[i]} tem {tamanhos[i]} caracteres");
            }
        }
    }
}
