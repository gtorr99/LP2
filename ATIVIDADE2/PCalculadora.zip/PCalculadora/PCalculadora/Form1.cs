﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        private double _number1;
        private double _number2;
        private double _resultado;
        
        public Form1()
        {
            InitializeComponent();
        }

        private Boolean maskTxtBoxN1_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtBoxN1.Text, out _number1))
            {
                MessageBox.Show("Número 1 Inválido!");
                e.Cancel = true;
                txtBoxN1.Focus();
                return false;
            }

            return true;
        } 
        
        private Boolean maskTxtBoxN2_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtBoxN2.Text, out _number2))
            {
                MessageBox.Show("Número 2 Inválido!");
                e.Cancel = true;
                txtBoxN2.Focus();
                return false;
            }

            return true;
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            if (maskTxtBoxN1_Validating(sender, new CancelEventArgs()) 
                && maskTxtBoxN2_Validating(sender, new CancelEventArgs()))
            {
                _resultado = _number1 + _number2;
                txtBoxResultado.Text = _resultado.ToString("N2");
            }
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            if (maskTxtBoxN1_Validating(sender, new CancelEventArgs())
                && maskTxtBoxN2_Validating(sender, new CancelEventArgs()))
            {
                _resultado = _number1 - _number2;
                txtBoxResultado.Text = _resultado.ToString("N2");
            }
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            if (maskTxtBoxN1_Validating(sender, new CancelEventArgs())
                && maskTxtBoxN2_Validating(sender, new CancelEventArgs()))
            {
                _resultado = _number1 * _number2;
                txtBoxResultado.Text = _resultado.ToString("N2");
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (maskTxtBoxN1_Validating(sender, new CancelEventArgs())
                && maskTxtBoxN2_Validating(sender, new CancelEventArgs()))
            {
                if (_number2 == 0)
                {
                    MessageBox.Show("Impossível divisão por zero!");
                    txtBoxN2.Focus();
                } 
                
                else
                {
                    _resultado = _number1 / _number2;
                    txtBoxResultado.Text = _resultado.ToString("N2");
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtBoxN1.Clear();
            txtBoxN2.Clear();
            txtBoxResultado.Clear();
            txtBoxN1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
