﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class FrmSalario : Form
    {
        private double _salarioBruto;
        private double _salarioLiquido;

        public FrmSalario()
        {
            InitializeComponent();
        }

        private void FrmSalario_Load(object sender, EventArgs e)
        {
            cbxNumFilhos.SelectedIndex = 0;
        }

        private Boolean TxtNome_Validating(object sender, CancelEventArgs e)
        {
            if (txtNome.TextLength == 0)
            {
                e.Cancel = true;
                MessageBox.Show("Nome obrigatório!");
                txtNome.Focus();
                return false;
            }

            return true;
        }

        private Boolean MskbxSalarioBruto_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxSalarioBruto.Text, out _salarioBruto))
            {
                e.Cancel = true;
                MessageBox.Show("Salário Bruto Inválido!");
                mskbxSalarioBruto.Focus();
                return false;
            }

            if (_salarioBruto < 1)
            {
                MessageBox.Show("Salário Bruto deve ser maior que zero!");
                mskbxSalarioBruto.Focus();
                return false;
            }

            return true;
        }

        private void BtnVerificarDesconto_Click(object sender, EventArgs e)
        {
            if (TxtNome_Validating(sender, new CancelEventArgs())
                 && MskbxSalarioBruto_Validating(sender, new CancelEventArgs()))
            {
                _salarioLiquido = _salarioBruto;

                SetDadosFuncionario();
                CalcularAliquotaInss();
                CalcularAliquotaIrpf();
                CalcularSalarioFamilia();

                txtSalarioLiquido.Text = _salarioLiquido.ToString();
            }

        }

        private void SetDadosFuncionario(){
            lblDados.Text = "Os descontos do salário";

            if (rbtnFeminino.Checked)
            {
                lblDados.Text += $" da Sra. {txtNome.Text}";
                lblDados.Text += $" que é {(ckbxCasado.Checked ? "Casada" : "Solteira")}";
            } 
            else
            {
                lblDados.Text += $" do Sr. {txtNome.Text}";
                lblDados.Text += $" que é {(ckbxCasado.Checked ? "Casado" : "Solteiro")}";
            }

            if (cbxNumFilhos.SelectedIndex != 0)
            {
                lblDados.Text += $" e tem {cbxNumFilhos.SelectedIndex} filho{(cbxNumFilhos.SelectedIndex != 1 ? "s" : "")}";
            } 
            else
            {
                lblDados.Text += " e não tem filhos";
            }

            lblDados.Text += " são:";
        }

        private void CalcularAliquotaInss()
        {
            double teto = 308.17;
            double descontoInss = 0.00;

            if (_salarioBruto <= 800.47)
            {
                txtAliqInss.Text = "7.65%";
                descontoInss = 0.0765 * _salarioBruto;
            }
            else if (_salarioBruto >= 800.48 && _salarioBruto <= 1050)
            {
                txtAliqInss.Text = "8.65%";
                descontoInss = 0.0865 * _salarioBruto;
            }
            else if (_salarioBruto >= 1050.01 && _salarioBruto <= 1400.77)
            {
                txtAliqInss.Text = "9.00%";
                descontoInss = 0.09 * _salarioBruto;
            }
            else if (_salarioBruto >= 1400.78 && _salarioBruto <= 2801.56)
            {
                txtAliqInss.Text = "11.00%";
                descontoInss = 0.11 * _salarioBruto;
            } 
            else
            {
                txtAliqInss.Text = "Teto";
                descontoInss = teto;
            }

            txtDescontoInss.Text = descontoInss.ToString();
            _salarioLiquido -= descontoInss;
        }

        private void CalcularAliquotaIrpf()
        {
            double descontoIrpf = 0.00;

            if (_salarioBruto <= 1257.12)
            {
                txtAliqIrpf.Text = "Isento";
            }
            else if (_salarioBruto >= 1257.13 && _salarioBruto <= 2512.08)
            {
                txtAliqIrpf.Text = "15.00%";
                descontoIrpf = 0.15 * _salarioBruto;
            }
            else
            {
                txtAliqIrpf.Text = "27.5%";
                descontoIrpf = 0.275 * _salarioBruto;
            }

            txtDescontoIrpf.Text = descontoIrpf.ToString();
            _salarioLiquido -= descontoIrpf;
        }

        private void CalcularSalarioFamilia()
        {
            double salarioFamilia = 0.00;

            if (_salarioBruto <= 435.52)
            {
                salarioFamilia = 22.33 * cbxNumFilhos.SelectedIndex;
            } 
            else if (_salarioBruto >= 435.53 && _salarioBruto <= 654.61)
            {
                salarioFamilia = 15.74 * cbxNumFilhos.SelectedIndex;
            } 

             txtSalarioFamilia.Text = salarioFamilia.ToString();
            _salarioLiquido += salarioFamilia;
        }
    }
}
