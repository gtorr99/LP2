﻿namespace PSalario
{
    partial class FrmSalario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.mskbxSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.lblDados = new System.Windows.Forms.Label();
            this.lblAliqInss = new System.Windows.Forms.Label();
            this.lblAliqIrpf = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.lblSalarioLiquido = new System.Windows.Forms.Label();
            this.txtAliqInss = new System.Windows.Forms.TextBox();
            this.txtAliqIrpf = new System.Windows.Forms.TextBox();
            this.txtSalarioFamilia = new System.Windows.Forms.TextBox();
            this.txtSalarioLiquido = new System.Windows.Forms.TextBox();
            this.lblDescontoInss = new System.Windows.Forms.Label();
            this.lblDescontoIrpf = new System.Windows.Forms.Label();
            this.txtDescontoInss = new System.Windows.Forms.TextBox();
            this.txtDescontoIrpf = new System.Windows.Forms.TextBox();
            this.btnVerificarDesconto = new System.Windows.Forms.Button();
            this.grpbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnMasculino = new System.Windows.Forms.RadioButton();
            this.rbtnFeminino = new System.Windows.Forms.RadioButton();
            this.pnlCasado = new System.Windows.Forms.Panel();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.cbxNumFilhos = new System.Windows.Forms.ComboBox();
            this.grpbxSexo.SuspendLayout();
            this.pnlCasado.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(24, 28);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(90, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome funcionário";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Location = new System.Drawing.Point(24, 61);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(66, 13);
            this.lblSalarioBruto.TabIndex = 0;
            this.lblSalarioBruto.Text = "Salário bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(24, 95);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(86, 13);
            this.lblNumFilhos.TabIndex = 0;
            this.lblNumFilhos.Text = "Número de filhos";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(120, 25);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(182, 20);
            this.txtNome.TabIndex = 1;
            // 
            // mskbxSalarioBruto
            // 
            this.mskbxSalarioBruto.Location = new System.Drawing.Point(120, 58);
            this.mskbxSalarioBruto.Mask = "99990.00";
            this.mskbxSalarioBruto.Name = "mskbxSalarioBruto";
            this.mskbxSalarioBruto.Size = new System.Drawing.Size(182, 20);
            this.mskbxSalarioBruto.TabIndex = 2;
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDados.Location = new System.Drawing.Point(23, 191);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(49, 16);
            this.lblDados.TabIndex = 0;
            this.lblDados.Text = "Dados";
            // 
            // lblAliqInss
            // 
            this.lblAliqInss.AutoSize = true;
            this.lblAliqInss.Location = new System.Drawing.Point(23, 233);
            this.lblAliqInss.Name = "lblAliqInss";
            this.lblAliqInss.Size = new System.Drawing.Size(75, 13);
            this.lblAliqInss.TabIndex = 0;
            this.lblAliqInss.Text = "Alíquota INSS";
            // 
            // lblAliqIrpf
            // 
            this.lblAliqIrpf.AutoSize = true;
            this.lblAliqIrpf.Location = new System.Drawing.Point(23, 268);
            this.lblAliqIrpf.Name = "lblAliqIrpf";
            this.lblAliqIrpf.Size = new System.Drawing.Size(74, 13);
            this.lblAliqIrpf.TabIndex = 0;
            this.lblAliqIrpf.Text = "Alíquota IRPF";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.Location = new System.Drawing.Point(23, 302);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(76, 13);
            this.lblSalarioFamilia.TabIndex = 0;
            this.lblSalarioFamilia.Text = "Salário Família";
            // 
            // lblSalarioLiquido
            // 
            this.lblSalarioLiquido.AutoSize = true;
            this.lblSalarioLiquido.Location = new System.Drawing.Point(23, 338);
            this.lblSalarioLiquido.Name = "lblSalarioLiquido";
            this.lblSalarioLiquido.Size = new System.Drawing.Size(78, 13);
            this.lblSalarioLiquido.TabIndex = 0;
            this.lblSalarioLiquido.Text = "Salário Líquido";
            // 
            // txtAliqInss
            // 
            this.txtAliqInss.Location = new System.Drawing.Point(105, 230);
            this.txtAliqInss.Name = "txtAliqInss";
            this.txtAliqInss.ReadOnly = true;
            this.txtAliqInss.Size = new System.Drawing.Size(197, 20);
            this.txtAliqInss.TabIndex = 8;
            // 
            // txtAliqIrpf
            // 
            this.txtAliqIrpf.Location = new System.Drawing.Point(105, 265);
            this.txtAliqIrpf.Name = "txtAliqIrpf";
            this.txtAliqIrpf.ReadOnly = true;
            this.txtAliqIrpf.Size = new System.Drawing.Size(197, 20);
            this.txtAliqIrpf.TabIndex = 9;
            // 
            // txtSalarioFamilia
            // 
            this.txtSalarioFamilia.Location = new System.Drawing.Point(105, 299);
            this.txtSalarioFamilia.Name = "txtSalarioFamilia";
            this.txtSalarioFamilia.ReadOnly = true;
            this.txtSalarioFamilia.Size = new System.Drawing.Size(197, 20);
            this.txtSalarioFamilia.TabIndex = 10;
            // 
            // txtSalarioLiquido
            // 
            this.txtSalarioLiquido.Location = new System.Drawing.Point(105, 335);
            this.txtSalarioLiquido.Name = "txtSalarioLiquido";
            this.txtSalarioLiquido.ReadOnly = true;
            this.txtSalarioLiquido.Size = new System.Drawing.Size(197, 20);
            this.txtSalarioLiquido.TabIndex = 11;
            // 
            // lblDescontoInss
            // 
            this.lblDescontoInss.AutoSize = true;
            this.lblDescontoInss.Location = new System.Drawing.Point(326, 233);
            this.lblDescontoInss.Name = "lblDescontoInss";
            this.lblDescontoInss.Size = new System.Drawing.Size(81, 13);
            this.lblDescontoInss.TabIndex = 0;
            this.lblDescontoInss.Text = "Desconto INSS";
            // 
            // lblDescontoIrpf
            // 
            this.lblDescontoIrpf.AutoSize = true;
            this.lblDescontoIrpf.Location = new System.Drawing.Point(327, 268);
            this.lblDescontoIrpf.Name = "lblDescontoIrpf";
            this.lblDescontoIrpf.Size = new System.Drawing.Size(80, 13);
            this.lblDescontoIrpf.TabIndex = 0;
            this.lblDescontoIrpf.Text = "Desconto IRPF";
            // 
            // txtDescontoInss
            // 
            this.txtDescontoInss.Location = new System.Drawing.Point(413, 230);
            this.txtDescontoInss.Name = "txtDescontoInss";
            this.txtDescontoInss.ReadOnly = true;
            this.txtDescontoInss.Size = new System.Drawing.Size(149, 20);
            this.txtDescontoInss.TabIndex = 12;
            // 
            // txtDescontoIrpf
            // 
            this.txtDescontoIrpf.Location = new System.Drawing.Point(413, 265);
            this.txtDescontoIrpf.Name = "txtDescontoIrpf";
            this.txtDescontoIrpf.ReadOnly = true;
            this.txtDescontoIrpf.Size = new System.Drawing.Size(149, 20);
            this.txtDescontoIrpf.TabIndex = 13;
            // 
            // btnVerificarDesconto
            // 
            this.btnVerificarDesconto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVerificarDesconto.Location = new System.Drawing.Point(120, 131);
            this.btnVerificarDesconto.Name = "btnVerificarDesconto";
            this.btnVerificarDesconto.Size = new System.Drawing.Size(182, 32);
            this.btnVerificarDesconto.TabIndex = 7;
            this.btnVerificarDesconto.Text = "Verificar Desconto";
            this.btnVerificarDesconto.UseVisualStyleBackColor = true;
            this.btnVerificarDesconto.Click += new System.EventHandler(this.BtnVerificarDesconto_Click);
            // 
            // grpbxSexo
            // 
            this.grpbxSexo.Controls.Add(this.rbtnMasculino);
            this.grpbxSexo.Controls.Add(this.rbtnFeminino);
            this.grpbxSexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxSexo.Location = new System.Drawing.Point(330, 25);
            this.grpbxSexo.Name = "grpbxSexo";
            this.grpbxSexo.Size = new System.Drawing.Size(232, 82);
            this.grpbxSexo.TabIndex = 4;
            this.grpbxSexo.TabStop = false;
            this.grpbxSexo.Text = "Sexo";
            // 
            // rbtnMasculino
            // 
            this.rbtnMasculino.AutoSize = true;
            this.rbtnMasculino.Location = new System.Drawing.Point(18, 46);
            this.rbtnMasculino.Name = "rbtnMasculino";
            this.rbtnMasculino.Size = new System.Drawing.Size(37, 20);
            this.rbtnMasculino.TabIndex = 5;
            this.rbtnMasculino.Text = "M";
            this.rbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // rbtnFeminino
            // 
            this.rbtnFeminino.AutoSize = true;
            this.rbtnFeminino.Checked = true;
            this.rbtnFeminino.Location = new System.Drawing.Point(18, 20);
            this.rbtnFeminino.Name = "rbtnFeminino";
            this.rbtnFeminino.Size = new System.Drawing.Size(34, 20);
            this.rbtnFeminino.TabIndex = 4;
            this.rbtnFeminino.TabStop = true;
            this.rbtnFeminino.Text = "F";
            this.rbtnFeminino.UseVisualStyleBackColor = true;
            // 
            // pnlCasado
            // 
            this.pnlCasado.Controls.Add(this.ckbxCasado);
            this.pnlCasado.Location = new System.Drawing.Point(330, 113);
            this.pnlCasado.Name = "pnlCasado";
            this.pnlCasado.Size = new System.Drawing.Size(232, 50);
            this.pnlCasado.TabIndex = 5;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(17, 17);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(62, 17);
            this.ckbxCasado.TabIndex = 6;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // cbxNumFilhos
            // 
            this.cbxNumFilhos.FormattingEnabled = true;
            this.cbxNumFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.cbxNumFilhos.Location = new System.Drawing.Point(120, 92);
            this.cbxNumFilhos.Name = "cbxNumFilhos";
            this.cbxNumFilhos.Size = new System.Drawing.Size(182, 21);
            this.cbxNumFilhos.TabIndex = 3;
            // 
            // FrmSalario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 380);
            this.Controls.Add(this.cbxNumFilhos);
            this.Controls.Add(this.pnlCasado);
            this.Controls.Add(this.grpbxSexo);
            this.Controls.Add(this.btnVerificarDesconto);
            this.Controls.Add(this.mskbxSalarioBruto);
            this.Controls.Add(this.txtSalarioLiquido);
            this.Controls.Add(this.txtSalarioFamilia);
            this.Controls.Add(this.txtAliqIrpf);
            this.Controls.Add(this.txtDescontoIrpf);
            this.Controls.Add(this.txtDescontoInss);
            this.Controls.Add(this.txtAliqInss);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblSalarioLiquido);
            this.Controls.Add(this.lblSalarioFamilia);
            this.Controls.Add(this.lblAliqIrpf);
            this.Controls.Add(this.lblDescontoIrpf);
            this.Controls.Add(this.lblDescontoInss);
            this.Controls.Add(this.lblAliqInss);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNome);
            this.Name = "FrmSalario";
            this.Text = "PSalario";
            this.Load += new System.EventHandler(this.FrmSalario_Load);
            this.grpbxSexo.ResumeLayout(false);
            this.grpbxSexo.PerformLayout();
            this.pnlCasado.ResumeLayout(false);
            this.pnlCasado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioBruto;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Label lblAliqInss;
        private System.Windows.Forms.Label lblAliqIrpf;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label lblSalarioLiquido;
        private System.Windows.Forms.TextBox txtAliqInss;
        private System.Windows.Forms.TextBox txtAliqIrpf;
        private System.Windows.Forms.TextBox txtSalarioFamilia;
        private System.Windows.Forms.TextBox txtSalarioLiquido;
        private System.Windows.Forms.Label lblDescontoInss;
        private System.Windows.Forms.Label lblDescontoIrpf;
        private System.Windows.Forms.TextBox txtDescontoInss;
        private System.Windows.Forms.TextBox txtDescontoIrpf;
        private System.Windows.Forms.Button btnVerificarDesconto;
        private System.Windows.Forms.GroupBox grpbxSexo;
        private System.Windows.Forms.RadioButton rbtnMasculino;
        private System.Windows.Forms.RadioButton rbtnFeminino;
        private System.Windows.Forms.Panel pnlCasado;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.ComboBox cbxNumFilhos;
    }
}

