﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        private double _ladoA;
        private double _ladoB;
        private double _ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private Boolean TxtLadoA_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out _ladoA))
            {
                e.Cancel = true;
                return ValorInvalido("Lado A Inválido!", txtLadoA);
            }

            if (_ladoA < 1)
            {
                e.Cancel = true;
                return ValorInvalido("Lado A deve ser maior que zero!", txtLadoA);
            }

            return true;
        }

        private Boolean TxtLadoB_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out _ladoB))
            {
                e.Cancel = true;
                return ValorInvalido("Lado B Inválido!", txtLadoB);
            }

            if (_ladoB < 1)
            {
                e.Cancel = true;
                return ValorInvalido("Lado B deve ser maior que zero!", txtLadoB);
            }

            return true;
        }

        private Boolean TxtLadoC_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out _ladoC))
            {
                e.Cancel = true;
                return ValorInvalido("Lado C Inválido!", txtLadoC);
            }

            if (_ladoC < 1)
            {
                e.Cancel = true;
                return ValorInvalido("Lado C deve ser maior que zero!", txtLadoC);
            }

            return true;
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
            txtLadoA.Focus();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            if (TxtLadoA_Validating(sender, new CancelEventArgs())
                && TxtLadoB_Validating(sender, new CancelEventArgs())
                && TxtLadoC_Validating(sender, new CancelEventArgs())
                && ValidarRegraDosTriangulos())
            {
                VerificarTipoTriangulo();
            }
        }

        private Boolean ValorInvalido(String msgErro, TextBox textBox)
        {
            MessageBox.Show(msgErro);
            textBox.Focus();
            return false;
        }

        private Boolean ValidarRegraDosTriangulos()
        {
            if (!ValidarLado(_ladoA, _ladoB, _ladoC))
            {
                return ValorInvalido("Lado A incorreto na Regra dos Triângulos", txtLadoA);
            }
            
            if (!ValidarLado(_ladoB, _ladoA, _ladoC))
            {
                return ValorInvalido("Lado B incorreto na Regra dos Triângulos", txtLadoB);
            }
            
            if (!ValidarLado(_ladoC, _ladoA, _ladoB))
            {
                return ValorInvalido("Lado C incorreto na Regra dos Triângulos", txtLadoC);
            }

            return true;
        }

        private Boolean ValidarLado(double ladoVerificar, double lado1, double lado2)
        {
            return ladoVerificar > Math.Abs(lado1 - lado2) && ladoVerificar < lado1 + lado2;
        }

        private void VerificarTipoTriangulo()
        {
            if (_ladoA == _ladoB && _ladoB == _ladoC)
            {
                MessageBox.Show("Triângulo Equilátero!");
            }
            
            else if (_ladoA == _ladoB || _ladoA == _ladoC || _ladoB == _ladoC)
            {
                MessageBox.Show("Triângulo Isósceles!");
            }
            
            else if (_ladoA != _ladoB && _ladoB != _ladoC)
            {
                MessageBox.Show("Triângulo Escaleno!");
            }
        }
    }
}
