﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void VerificarFormAberto(string formName)
        {
            Form fc = Application.OpenForms[formName];

            if (fc != null)
            {
                fc.Close();
            }
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmExercicio2");

            frmExercicio2 frm = new frmExercicio2
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized,
            };

            frm.Show();
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmExercicio3");

            frmExercicio3 frm3 = new frmExercicio3
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized,
            };

            frm3.Show();
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmExercicio4");

            frmExercicio4 frm4 = new frmExercicio4
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized,
            };

            frm4.Show();
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmExercicio5");

            frmExercicio5 frm5 = new frmExercicio5
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized,
            };

            frm5.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ctrl + V");
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ctrl + C");
        }
    }
}
