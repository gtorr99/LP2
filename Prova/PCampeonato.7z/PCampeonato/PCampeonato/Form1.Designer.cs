﻿namespace PCampeonato
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstbxResultado = new System.Windows.Forms.ListBox();
            this.btnInserirGols = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstbxResultado
            // 
            this.lstbxResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstbxResultado.FormattingEnabled = true;
            this.lstbxResultado.ItemHeight = 16;
            this.lstbxResultado.Items.AddRange(new object[] {
            " "});
            this.lstbxResultado.Location = new System.Drawing.Point(77, 36);
            this.lstbxResultado.Name = "lstbxResultado";
            this.lstbxResultado.Size = new System.Drawing.Size(431, 196);
            this.lstbxResultado.TabIndex = 0;
            // 
            // btnInserirGols
            // 
            this.btnInserirGols.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInserirGols.Location = new System.Drawing.Point(322, 241);
            this.btnInserirGols.Name = "btnInserirGols";
            this.btnInserirGols.Size = new System.Drawing.Size(186, 42);
            this.btnInserirGols.TabIndex = 1;
            this.btnInserirGols.Text = "Inserir Gols";
            this.btnInserirGols.UseVisualStyleBackColor = true;
            this.btnInserirGols.Click += new System.EventHandler(this.btnInserirGols_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 328);
            this.Controls.Add(this.btnInserirGols);
            this.Controls.Add(this.lstbxResultado);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstbxResultado;
        private System.Windows.Forms.Button btnInserirGols;
    }
}

