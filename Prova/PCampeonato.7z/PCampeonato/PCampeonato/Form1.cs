﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PCampeonato
{
    public partial class Form1 : Form
    {
        private const int _N = 9;
        private int[,] _golsPorTime = new int[_N, 3];

        /* Cenários de Teste 
         * 5,9,-4
         * 16,2,14
         * 5,9,-4
         */


        public Form1()
        {
            InitializeComponent();
        }

        private void btnInserirGols_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
            ReceberGols();
            ExibirResultado();
        }

        private void ReceberGols()
        {
            string aux;
            int nomeTime = 0;

            for (int time = 0; time < _N; time++)
            {
                nomeTime = time + 1;
                aux = Interaction.InputBox("Gols feitos: ", "Time " + nomeTime);

                if (aux == "")
                    return;

                if (!int.TryParse(aux, out _golsPorTime[time, 0]) || _golsPorTime[time, 0] < 0)
                {
                    MessageBox.Show("Gols feitos deve ser um número maior que zero!", "Valor Inválido");
                    time--;
                    continue;
                }

                aux = Interaction.InputBox("Gols recebidos: ", "Time " + nomeTime);

                if (aux == "")
                    return;

                if (!int.TryParse(aux, out _golsPorTime[time, 1]) || _golsPorTime[time, 1] < 0)
                {
                    MessageBox.Show("Gols recebidos deve ser um número maior que zero!", "Valor Inválido");
                    time--;
                    continue;
                }

                _golsPorTime[time, 2] = _golsPorTime[time, 0] - _golsPorTime[time, 1];
            }
        }

        private void ExibirResultado()
        {
            
            int golsFeitos = 0;
            int golsRecebidos = 0;
            int saldo = 0;
            List<int> indexPiores = new List<int>();
            List<int> indexMelhores = new List<int>();
            int nomeTime = 0;

            indexPiores.Add(0);
            indexMelhores.Add(0);

            for (int time = 0; time < _N; time++)
            {
                golsFeitos = _golsPorTime[time, 0];
                golsRecebidos = _golsPorTime[time, 1];
                saldo = _golsPorTime[time, 2];

                nomeTime = time + 1;

                lstbxResultado.Items.Add("Time: " + nomeTime + " Gols feitos: " + golsFeitos + 
                    " Gols recebidos: " + golsRecebidos + " Saldo de Gols: " + saldo);

                if (time != 0 & saldo <= _golsPorTime[indexPiores[0], 2])
                {
                    if (saldo < _golsPorTime[indexPiores[0], 2]) 
                    {
                        indexPiores.Clear();
                    }
                        
                    indexPiores.Add(time);
                   
                }

                if (time != 0 & saldo >= _golsPorTime[indexMelhores[0], 2])
                {
                    if (saldo > _golsPorTime[indexMelhores[0], 2])
                    {
                       indexMelhores.Clear();
                    }

                    indexMelhores.Add(time);
                }
            }

            lstbxResultado.Items.Add("--------------------------------------------");

            StringBuilder sb = new StringBuilder();
            sb.Append("Pior(es) Time(s): ");

            string[] piores = new string[indexPiores.Count];
            for (int i = 0; i < indexPiores.Count; i++)
            {
                nomeTime = indexPiores[i] + 1;
                piores[i] = "Time: " + nomeTime;
            }

            sb.Append(string.Join(" e ", piores));
            sb.Append(" Pior(es) Saldo(s) de Gol(s): " + _golsPorTime[indexPiores[0], 2] + "\n");
            lstbxResultado.Items.Add(sb.ToString());
            sb.Clear();

            sb.Append("Melhor(es) Time(s): ");

            string[] melhores = new string[indexMelhores.Count];
            for (int i = 0; i < indexMelhores.Count; i++)
            {
                nomeTime = indexMelhores[i] + 1;
                melhores[i] = "Time: " + nomeTime;
            }

            sb.Append(string.Join(" e ", melhores));
            sb.Append(" Melhor(es) Saldo(s) de Gol(s): " + _golsPorTime[indexMelhores[0], 2]);
            lstbxResultado.Items.Add(sb.ToString());
       
        }
    }
}
