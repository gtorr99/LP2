﻿namespace PFerramenta
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picBoxJavaVsCsharp = new System.Windows.Forms.PictureBox();
            this.lblSobre = new System.Windows.Forms.Label();
            this.lblAluno = new System.Windows.Forms.Label();
            this.lblNomeAluno = new System.Windows.Forms.Label();
            this.lblRA = new System.Windows.Forms.Label();
            this.lblRAValor = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxJavaVsCsharp)).BeginInit();
            this.SuspendLayout();
            // 
            // picBoxJavaVsCsharp
            // 
            this.picBoxJavaVsCsharp.Image = global::PFerramenta.Properties.Resources.java_vs_c_;
            this.picBoxJavaVsCsharp.Location = new System.Drawing.Point(-1, 1);
            this.picBoxJavaVsCsharp.Name = "picBoxJavaVsCsharp";
            this.picBoxJavaVsCsharp.Size = new System.Drawing.Size(230, 402);
            this.picBoxJavaVsCsharp.TabIndex = 0;
            this.picBoxJavaVsCsharp.TabStop = false;
            // 
            // lblSobre
            // 
            this.lblSobre.AutoSize = true;
            this.lblSobre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSobre.Location = new System.Drawing.Point(240, 9);
            this.lblSobre.Name = "lblSobre";
            this.lblSobre.Size = new System.Drawing.Size(57, 20);
            this.lblSobre.TabIndex = 1;
            this.lblSobre.Text = "Sobre";
            // 
            // lblAluno
            // 
            this.lblAluno.AutoSize = true;
            this.lblAluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAluno.Location = new System.Drawing.Point(247, 63);
            this.lblAluno.Name = "lblAluno";
            this.lblAluno.Size = new System.Drawing.Size(50, 16);
            this.lblAluno.TabIndex = 1;
            this.lblAluno.Text = "Aluno:";
            // 
            // lblNomeAluno
            // 
            this.lblNomeAluno.AutoSize = true;
            this.lblNomeAluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeAluno.Location = new System.Drawing.Point(303, 63);
            this.lblNomeAluno.Name = "lblNomeAluno";
            this.lblNomeAluno.Size = new System.Drawing.Size(163, 16);
            this.lblNomeAluno.TabIndex = 1;
            this.lblNomeAluno.Text = "Gabriel Torres Guimarães";
            // 
            // lblRA
            // 
            this.lblRA.AutoSize = true;
            this.lblRA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRA.Location = new System.Drawing.Point(247, 93);
            this.lblRA.Name = "lblRA";
            this.lblRA.Size = new System.Drawing.Size(32, 16);
            this.lblRA.TabIndex = 1;
            this.lblRA.Text = "RA:";
            // 
            // lblRAValor
            // 
            this.lblRAValor.AutoSize = true;
            this.lblRAValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRAValor.Location = new System.Drawing.Point(303, 93);
            this.lblRAValor.Name = "lblRAValor";
            this.lblRAValor.Size = new System.Drawing.Size(98, 16);
            this.lblRAValor.TabIndex = 1;
            this.lblRAValor.Text = "0030481823019";
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(497, 403);
            this.Controls.Add(this.lblRAValor);
            this.Controls.Add(this.lblRA);
            this.Controls.Add(this.lblNomeAluno);
            this.Controls.Add(this.lblAluno);
            this.Controls.Add(this.lblSobre);
            this.Controls.Add(this.picBoxJavaVsCsharp);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            ((System.ComponentModel.ISupportInitialize)(this.picBoxJavaVsCsharp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picBoxJavaVsCsharp;
        private System.Windows.Forms.Label lblSobre;
        private System.Windows.Forms.Label lblAluno;
        private System.Windows.Forms.Label lblNomeAluno;
        private System.Windows.Forms.Label lblRA;
        private System.Windows.Forms.Label lblRAValor;
    }
}