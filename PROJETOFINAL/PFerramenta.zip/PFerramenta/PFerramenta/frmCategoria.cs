﻿using PFerramenta.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFerramenta
{
    public partial class frmCategoria : Form
    {
        private BindingSource bnCategoria = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsCategoria = new DataSet();

        public frmCategoria()
        {
            InitializeComponent();
        }

        private void frmCategoria_Load(object sender, EventArgs e)
        {
            try
            {
                Categoria categoria = new Categoria();
                dsCategoria.Tables.Add(categoria.Listar());
                bnCategoria.DataSource = dsCategoria.Tables["Categoria"];
                dgvCategoria.DataSource = bnCategoria;
                bnvCategoria.BindingSource = bnCategoria;

                txtIdCategoria.DataBindings.Add("TEXT", bnCategoria, "idcategoria");
                txtDescricao.DataBindings.Add("TEXT", bnCategoria, "descricao");

                txtDescricao.Enabled = false;

                btnNovo.Enabled = true;
                btnAlterar.Enabled = txtIdCategoria.Text != null;
                btnExcluir.Enabled = true;
                btnSalvar.Enabled = false;
                btnCancelar.Enabled = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Falha ao carregar form Categoria", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void MudarTab()
        {
            if (tbCategoria.SelectedIndex == 0)
            {
                tbCategoria.SelectTab(1);
            }
        }

        private void CarregarTabela(Categoria ferr)
        {
            dsCategoria.Tables.Clear();
            dsCategoria.Tables.Add(ferr.Listar());
            bnCategoria.DataSource = dsCategoria.Tables["Categoria"];
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            MudarTab();

            bnCategoria.AddNew();

            txtDescricao.Enabled = true;
            txtDescricao.Focus();

            btnNovo.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtDescricao.Text))
            {
                MessageBox.Show("Descrição inválida!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDescricao.Focus();
            }
            else
            {
                Categoria RegCateg = new Categoria();

                RegCateg.Descricao = txtDescricao.Text;

                if (bInclusao)
                {
                    if (RegCateg.Salvar() > 0)
                    {
                        MessageBox.Show("Categoria adicionada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        txtDescricao.Enabled = false;

                        btnNovo.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;
                        bInclusao = false;

                        CarregarTabela(RegCateg);
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Categoria!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    RegCateg.IdCategoria = Convert.ToInt32(txtIdCategoria.Text);

                    if (RegCateg.Alterar() > 0)
                    {
                        MessageBox.Show("Categoria alterada com sucesso!");

                        txtDescricao.Enabled = false;

                        btnNovo.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;
                        bInclusao = false;

                        CarregarTabela(RegCateg);
                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar categoria!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            MudarTab();

            txtDescricao.Enabled = true;

            btnNovo.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Categoria RegCateg = new Categoria();

                RegCateg.IdCategoria = Convert.ToInt32(txtIdCategoria.Text);

                if (RegCateg.Excluir() > 0)
                {
                    MessageBox.Show("Categoria excluída com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CarregarTabela(RegCateg);
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Categoria!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Confirma cancelamento?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                bnCategoria.CancelEdit();

                txtDescricao.Enabled = false;

                btnNovo.Enabled = true;
                btnAlterar.Enabled = true;
                btnExcluir.Enabled = true;
                btnSalvar.Enabled = false;
                btnCancelar.Enabled = false;
                bInclusao = false;
            }
        }
    }
}
