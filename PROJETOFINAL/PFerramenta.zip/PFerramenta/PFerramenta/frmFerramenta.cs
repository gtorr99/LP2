﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PFerramenta.model;

namespace PFerramenta
{
    public partial class frmFerramenta : Form
    {
        private BindingSource bnFerramenta = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsFerramenta = new DataSet();
        private DataSet dsCategoria = new DataSet();


        public frmFerramenta()
        {
            InitializeComponent();
        }

        private void frmFerramenta_Load(object sender, EventArgs e)
        {
            try
            {
                Ferramenta ferramenta = new Ferramenta();
                dsFerramenta.Tables.Add(ferramenta.Listar());
                bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];
                dgvFerramenta.DataSource = bnFerramenta;
                bnvFerramenta.BindingSource = bnFerramenta;

                txtIdFerramenta.DataBindings.Add("TEXT", bnFerramenta, "idferramenta");
                txtNome.DataBindings.Add("TEXT", bnFerramenta, "nome");
                txtFornecedor.DataBindings.Add("TEXT", bnFerramenta, "fornecedor");
                txtSiteOficial.DataBindings.Add("TEXT", bnFerramenta, "siteoficial");
                dtpDtCadastro.DataBindings.Add("TEXT", bnFerramenta, "dtcadastro");

                cbxDistribuicao.DataBindings.Add("SelectedItem", bnFerramenta, "distribuicao");

                Categoria categoria = new Categoria();
                dsCategoria.Tables.Add(categoria.Listar());

                cbxCategoria.DataSource = dsCategoria.Tables["Categoria"];
                cbxCategoria.DisplayMember = "descricao";
                cbxCategoria.ValueMember = "idcategoria";
                cbxCategoria.DataBindings.Add("SelectedValue", bnFerramenta, "categoria_idcategoria");

                txtNome.Enabled = false;
                txtFornecedor.Enabled = false;
                txtSiteOficial.Enabled = false;
                cbxDistribuicao.Enabled = false;
                dtpDtCadastro.Enabled = false;
                cbxDistribuicao.Enabled = false;
                cbxCategoria.Enabled = false;

                btnNovo.Enabled = true;
                btnAlterar.Enabled = txtIdFerramenta.Text != null;
                btnExcluir.Enabled = true;
                btnSalvar.Enabled = false;
                btnCancelar.Enabled = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Falha ao carregar form Ferramenta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void MudarTab()
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }
        }

        private void CarregarTabela(Ferramenta ferr)
        {
            dsFerramenta.Tables.Clear();
            dsFerramenta.Tables.Add(ferr.Listar());
            bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            MudarTab();

            bnFerramenta.AddNew();

            txtNome.Enabled = true;
            txtNome.Focus();

            txtFornecedor.Enabled = true;
            txtSiteOficial.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtpDtCadastro.Enabled = true;
            cbxDistribuicao.Enabled = true;
            cbxCategoria.Enabled = true;

            cbxCategoria.SelectedIndex = 0;
            cbxDistribuicao.SelectedIndex = 0;

            btnNovo.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtNome.Text))
            {
                MessageBox.Show("Nome inválido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNome.Focus();
            }
            else if (String.IsNullOrEmpty(txtFornecedor.Text))
            {
                MessageBox.Show("Fornecedor inválido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFornecedor.Focus();
            }
            else if (cbxDistribuicao.SelectedIndex == -1)
            {
                MessageBox.Show("Distribuição inválida!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cbxDistribuicao.Focus();
            }
            else if (String.IsNullOrEmpty(txtSiteOficial.Text))
            {
                MessageBox.Show("Site oficial inválido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSiteOficial.Focus();
            }
            else if (cbxCategoria.SelectedIndex == -1)
            {
                MessageBox.Show("Categoria inválida!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSiteOficial.Focus();
            }
            else
            {
                Ferramenta RegFerr = new Ferramenta();

                RegFerr.Nome = txtNome.Text;
                RegFerr.Fornecedor = txtFornecedor.Text;
                RegFerr.DtCadastro = dtpDtCadastro.Value;
                RegFerr.SiteOficial = txtSiteOficial.Text;
                RegFerr.Distribuicao = Char.Parse((cbxDistribuicao.SelectedIndex + 1).ToString());
                RegFerr.Categoria = Convert.ToInt32(cbxCategoria.SelectedValue.ToString());

                if (bInclusao)
                {
                    if (RegFerr.Salvar() > 0)
                    {
                        MessageBox.Show("Ferramenta adicionada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        txtNome.Enabled = false;
                        txtFornecedor.Enabled = false;
                        txtSiteOficial.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtpDtCadastro.Enabled = false;
                        cbxCategoria.Enabled = false;
                        cbxDistribuicao.Enabled = false;

                        btnNovo.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;
                        bInclusao = false;

                        CarregarTabela(RegFerr);
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Ferramenta!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    RegFerr.IdFerramenta = Convert.ToInt32(txtIdFerramenta.Text);

                    if (RegFerr.Alterar() > 0)
                    {
                        MessageBox.Show("Ferramenta alterada com sucesso!");

                        txtNome.Enabled = false;
                        txtFornecedor.Enabled = false;
                        txtSiteOficial.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtpDtCadastro.Enabled = false;
                        cbxCategoria.Enabled = false;
                        cbxDistribuicao.Enabled = false;

                        btnNovo.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;
                        bInclusao = false;

                        CarregarTabela(RegFerr);
                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar ferramenta!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            MudarTab();

            txtNome.Enabled = true;
            txtFornecedor.Enabled = true;
            txtSiteOficial.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtpDtCadastro.Enabled = true;
            cbxDistribuicao.Enabled = true;
            cbxCategoria.Enabled = true;

            btnNovo.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Ferramenta RegFerr = new Ferramenta();

                RegFerr.IdFerramenta = Convert.ToInt32(txtIdFerramenta.Text);

                if (RegFerr.Excluir() > 0)
                {
                    MessageBox.Show("Ferramenta excluída com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CarregarTabela(RegFerr);
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Ferramenta!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Confirma cancelamento?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                bnFerramenta.CancelEdit();

                txtNome.Enabled = false;
                txtFornecedor.Enabled = false;
                txtSiteOficial.Enabled = false;
                cbxDistribuicao.Enabled = false;
                dtpDtCadastro.Enabled = false;
                cbxCategoria.Enabled = false;
                cbxDistribuicao.Enabled = false;

                btnNovo.Enabled = true;
                btnAlterar.Enabled = true;
                btnExcluir.Enabled = true;
                btnSalvar.Enabled = false;
                btnCancelar.Enabled = false;
                bInclusao = false;
            }
        }
    }
}
