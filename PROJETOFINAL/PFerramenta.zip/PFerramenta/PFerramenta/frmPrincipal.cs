﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFerramenta
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void VerificarFormAberto(string formName)
        {
            Form fc = Application.OpenForms[formName];

            if (fc != null)
            {
                fc.Close();
            }
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=LP2;Trusted_Connection=True;");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Erro de banco de dados", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ferramentasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmCategoria");

            frmFerramenta frm = new frmFerramenta
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized,
            };

            this.Size = new Size(816, 489);
            frm.Show();
        }

        private void categoriasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmCategoria");

            frmCategoria frm = new frmCategoria
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized,
            };

            this.Size = new Size(816, 489);
            frm.Show();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VerificarFormAberto("frmSobre");

            frmSobre frm = new frmSobre
            {
                MdiParent = this,
                WindowState = FormWindowState.Maximized
            };

            this.Size = new Size(510, 460);
            frm.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                conexao.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Alerta de banco de dados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                Close();
            }
        }
    }
}
