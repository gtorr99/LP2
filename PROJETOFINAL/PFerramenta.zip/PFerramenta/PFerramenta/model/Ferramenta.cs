﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFerramenta.model
{
    public class Ferramenta
    {
        public int IdFerramenta { get; set; }
        public int Categoria { get; set; }
        public string Nome { get; set; }
        public string Fornecedor { get; set; }
        public string SiteOficial { get; set; }
        public char Distribuicao { get; set; }
        public DateTime DtCadastro { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daFerramenta;
            DataTable dtFerramenta = new DataTable();

            try
            {
                daFerramenta = new SqlDataAdapter("SELECT * FROM ferramenta ORDER BY CATEGORIA_idCATEGORIA, nome",
                frmPrincipal.conexao);
                daFerramenta.Fill(dtFerramenta);
                daFerramenta.FillSchema(dtFerramenta, SchemaType.Source);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Falha de conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw ex;
            }

            return dtFerramenta;
        }

        public int Salvar()
        {
            int retorno;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand(
                    "INSERT INTO ferramenta VALUES(" +
                        "@nome, " +
                        "@fornecedor, " +
                        "@distribuicao, " +
                        "@dtcadastro, " +
                        "@siteoficial, " +
                        "@categoria_idcategoria)",
                frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@nome", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@fornecedor", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@distribuicao", SqlDbType.Char));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastro", SqlDbType.DateTime));
                mycommand.Parameters.Add(new SqlParameter("@siteoficial", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@categoria_idcategoria", SqlDbType.Int));

                mycommand.Parameters["@nome"].Value = Nome;
                mycommand.Parameters["@fornecedor"].Value = Fornecedor;
                mycommand.Parameters["@distribuicao"].Value = Distribuicao;
                mycommand.Parameters["@dtcadastro"].Value = DtCadastro;
                mycommand.Parameters["@siteoficial"].Value = SiteOficial;
                mycommand.Parameters["@categoria_idcategoria"].Value = Categoria;

                retorno = mycommand.ExecuteNonQuery();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Falha ao Salvar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                retorno = -1;
            }

            return retorno;
        }

        public int Alterar()
        {
            int retorno;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand(
                    "UPDATE ferramenta SET " +
                        "nome = @nome, " +
                        "fornecedor=@fornecedor, " +
                        "distribuicao=@distribuicao," +
                        "dtcadastro=@dtcadastro, " +
                        "siteoficial=@siteoficial, " +
                        "categoria_idcategoria=@categoria_idcategoria " +
                    "WHERE idferramenta = @idferramenta",
                frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@idferramenta", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@nome", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@fornecedor", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@distribuicao", SqlDbType.Char));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastro", SqlDbType.DateTime));
                mycommand.Parameters.Add(new SqlParameter("@siteoficial", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@categoria_idcategoria", SqlDbType.Int));

                mycommand.Parameters["@idferramenta"].Value = IdFerramenta;
                mycommand.Parameters["@nome"].Value = Nome;
                mycommand.Parameters["@fornecedor"].Value = Fornecedor;
                mycommand.Parameters["@distribuicao"].Value = Distribuicao;
                mycommand.Parameters["@dtcadastro"].Value = DtCadastro;
                mycommand.Parameters["@siteoficial"].Value = SiteOficial;
                mycommand.Parameters["@categoria_idcategoria"].Value = Categoria;

                retorno = mycommand.ExecuteNonQuery();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Falha ao Alterar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                retorno = -1;
            }

            return retorno;
        }

        public int Excluir()
        {
            int retorno;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("DELETE FROM ferramenta WHERE idferramenta=@idferramenta", frmPrincipal.conexao);
                mycommand.Parameters.Add(new SqlParameter("@idferramenta", SqlDbType.Int));
                mycommand.Parameters["@idferramenta"].Value = IdFerramenta;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Falha ao Excluir", MessageBoxButtons.OK, MessageBoxIcon.Error);
                retorno = -1;
            }

            return retorno;
        }
    }
}
