﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        private double _altura;
        private double _peso;

        public Form1()
        {
            InitializeComponent();
        }

        private Boolean MaskTxtAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(maskTxtAltura.Text, out _altura))
            {
                MessageBox.Show("Altura Inválida!");
                e.Cancel = true;
                maskTxtAltura.Focus();
                return false;
            }

            if (_altura == 0)
            {
                MessageBox.Show("Altura deve ser maior que zero!");
                e.Cancel = true;
                maskTxtAltura.Focus();
                return false;
            }

            return true;
        }

        private Boolean MaskTxtPeso_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(maskTxtPeso.Text, out _peso))
            {
                MessageBox.Show("Peso Inválido!");
                e.Cancel = true;
                maskTxtPeso.Focus();
                return false;
            }
            
            if (_peso == 0)
            {
                MessageBox.Show("Peso deve ser maior que zero!");
                e.Cancel = true;
                maskTxtPeso.Focus();
                return false;
            }

            return true;
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            if (MaskTxtAltura_Validating(sender, new CancelEventArgs())
                && MaskTxtPeso_Validating(sender, new CancelEventArgs()))
            {

                String msg = GetMensagemIMC(CalcularIMC());

                MessageBox.Show(String.Concat("Classificação: ", msg));
            }
        }

        private Double CalcularIMC()
        {
            return _peso / Math.Pow(_altura, 2);
        }

        private String GetMensagemIMC(double imc)
        {
            if (imc < 18.5)
            {
                return "Magreza (0)\nPrecisa comer mais arroz com feijão!";
            }

            if (imc >= 18.5 && imc <= 24.9)
            {
                return "Normal (0)\nContinue assim!";
            }

            if (imc >= 25.0 && imc <= 29.9)
            {
                return "Sobrepeso (I)\nFaça mais exercícios!";
            }

            if (imc >= 30.0 && imc <= 39.9)
            {
                return "Obesidade (II)\nReveja a alimentação e o sedentarismo!";
            }

            if (imc >= 40.0)
            {
                return "Obesidade Grave (III)\nConsulte já seu médico!";
            }

            return "";
        }
    }
}
